column -t -s'|' songlist.txt 
