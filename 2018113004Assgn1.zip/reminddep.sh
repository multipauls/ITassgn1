sudo apt-get install notify-osd
